CREATE TABLE IF NOT EXISTS customers (
	id INT PRIMARY KEY AUTO_INCREMENT, 
	name VARCHAR(30), 
	phone_number VARCHAR(30),
	hair_type VARCHAR(30)
);
