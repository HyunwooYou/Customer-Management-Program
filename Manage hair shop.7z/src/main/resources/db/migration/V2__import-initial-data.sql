INSERT INTO customers (name, phone_number, hair_type) VALUES ('gachonh', '010-4023-4390', 'null1');
INSERT INTO customers (name, phone_number, hair_type) VALUES ('fage', '010-4323-4390', 'null2');
INSERT INTO customers (name, phone_number, hair_type) VALUES ('dgge', '010-4323-4421', 'null3');